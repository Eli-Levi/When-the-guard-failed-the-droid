import pandas as pd
import numpy as np

x1=pd.read_csv('data1_test.csv')
x2=pd.read_csv('data1_test_manipulated.csv')
x1['cat']=1
x2['cat']=2

x3=x1.append(x2)
m=x3.groupby('name').type.sum()
m=m[m==2]
m=m.index.to_list()
x1=x1[x1.name.isin( m)]
x2=x2[x2.name.isin( m)]
x1.drop(columns='cat',inplace=True)
x2.drop(columns='cat',inplace=True)

x1.to_csv('data1_test.csv',index=False)
x2.to_csv('data1_test_manipulated.csv',index=False)

x1=pd.read_csv('data2_test.csv')
x2=pd.read_csv('data2_test_manipulated.csv')
x1['cat']=1
x2['cat']=2

x3=x1.append(x2)
m=x3.groupby('name').type.sum()
m=m[m==2]
m=m.index.to_list()
x1=x1[x1.name.isin( m)]
x2=x2[x2.name.isin( m)]
x1.drop(columns='cat',inplace=True)
x2.drop(columns='cat',inplace=True)

x1.to_csv('data2_test.csv',index=False)
x2.to_csv('data2_test_manipulated.csv',index=False)

print(x3.shape)

x1=pd.read_csv('data3_test.csv')
x2=pd.read_csv('data3_test_manipulated.csv')
x1['cat']=1
x2['cat']=2

x3=x1.append(x2)
m=x3.groupby('name').type.sum()
m=m[m==2]
m=m.index.to_list()
x1=x1[x1.name.isin( m)]
x2=x2[x2.name.isin( m)]
x1.drop(columns='cat',inplace=True)
x2.drop(columns='cat',inplace=True)

x1.to_csv('data3_test.csv',index=False)
x2.to_csv('data3_test_manipulated.csv',index=False)

print(x3.shape)